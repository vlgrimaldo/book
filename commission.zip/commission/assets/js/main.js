var details = document.querySelector(".details");

var general = document.querySelector("#general");
var upholstery = document.querySelector("#upholstery");
var deep = document.querySelector("#deep");

var proceed = document.querySelector(".proceed");
var payment = document.querySelector(".pay-container");
var btnBook = document.querySelector(".btn-book");

var d = new Date();


function btnBooking(){
    details.classList.add("d-block");
}
function btnGeneral(){
    general.classList.add("d-block");
    proceed.classList.add("d-block");
    upholstery.classList.remove("d-block");
    deep.classList.remove("d-block");
}
function btnUpholstery(){
    general.classList.remove("d-block");
    upholstery.classList.add("d-block");
    proceed.classList.add("d-block");
    deep.classList.remove("d-block");
}
function btnDeep(){
    general.classList.remove("d-block");
    upholstery.classList.remove("d-block");
    deep.classList.add("d-block");
    proceed.classList.add("d-block");
}

function proceedPayment(){
    payment.classList.add("d-block");
    btnBook.classList.add("d-block");
}

